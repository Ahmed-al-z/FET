% Ouverture et acquisition des valeurs du ficher Excel
% Le fichier excel doit se trouver dans le même répertoire que ce script
% sous le nom "lab1"
opts = spreadsheetImportOptions("NumVariables", 4);
opts.Sheet = "Feuil1";
opts.DataRange = "A2:D402";
opts.VariableNames = ["XTrace1IVD1IID", "YTrace1IVD1IID", "XTrace1IVD1IID1", "YTrace1IVD1IID1"];
opts.VariableTypes = ["double", "double", "double", "double"];
data = readtable("lab1.xlsx", opts, "UseExcel", false);
vd=data{:,"XTrace1IVD1IID"};
idright=data{:,"YTrace1IVD1IID"};
vg=data{:,"XTrace1IVD1IID1"};
idleft=data{:,"YTrace1IVD1IID1"};
clear data;
clear opts;

% Mise en graphique
xlims=[-5, 31];
ylims=[0, 0.025];
figure;
lglabels={};
xlim(xlims);ylim(ylims);
ylabel('$I_D [A]$', 'interpreter', 'latex');
xlabel('$V_{DS}$ or $V_{GS} [V]$', 'interpreter', 'latex');
grid on;
hold on;

Vgtarget=-0.5;
plot(vg,idleft,'r');
lglabels=[lglabels;'$I_D\left( V_{GS} \right)$'];
plot(vd,idright,'b');
lglabels=[lglabels;'$I_D\left( V_{DS} @ V_{GS}=-0.5V \right)$'];
plot(Vgtarget*ones(1,2), ylims, 'g--')
lglabels=[lglabels;'$V_{GS}=-0.5 V$'];

index=find(abs(vg-Vgtarget)<0.01);
Idq=idleft(index);
plot(Vgtarget,Idq,'g*');
lglabels=[lglabels;'$I_{DQ}=I_D\left( V_{GS}=-0.5V \right)$'];
disp(['Idq=' num2str(round(1000*Idq,1)) ' mA']);

Vgconstraint=10;
Vdd=30;
R2=100e3;
R1=(Vdd-Vgconstraint).*R2./Vgconstraint;
disp(['R1=' num2str(round(R1./1000,1)) ' kOhm']);
disp(['R2=' num2str(round(R2./1000,1)) ' kOhm'])
plot(Vgconstraint, 0, 'm*');
lglabels=[lglabels;'$I_D(V_{G}=10 V)=0$'];

v=[Vgtarget;Vgconstraint];
i=[Idq; 0];
plot(v,i,'m');
lglabels=[lglabels;'$I_D=-\left( V_{GS}-V_{G} \right)/R_{S}$'];

slope=diff(i)./diff(v);
Rs=-1./slope;
R3=Rs;
disp(['Rs=' num2str(round(Rs,1)) ' ohm']);
plot([vg;vd], Idq*ones(length(vg)+length(vd),1), 'c--')
lglabels=[lglabels;'$I_D=I_{DQ}$'];

qindex=find(abs(idright-Idq)<eps);
Vdsq=vd(qindex);
plot(Vdsq, Idq, 'c*')
lglabels=[lglabels;'$I_D(V_{DS}=V_{DSQ})=I_{DQ}$'];

plot(Vdd, 0, 'k*');
lglabels=[lglabels;'$I_D(V_{GS}=V_{DD})=0$'];

Vdd=30;
plot(Vdd, 0, 'k*');
lglabels=[lglabels;'$I_D(V_{GS}=V_{DD})=0$'];
v=[Vdsq;Vdd];
i=[idright(qindex); 0];
slope=diff(i)./diff(v);
idload=slope*(vd-Vdd);
plot(vd,idload,'k');
lglabels=[lglabels;'$I_{Dload}$'];
plot(vd(1),idload(1),'y*')
lglabels=[lglabels;'$I_{Dload}(V_{DS=0})$'];
legend(lglabels, 'interpreter', 'latex', 'location', 'eastoutside');

% Affichage des valeurs du circuit
Rd=Vdd/idload(1)-Rs;
R4=Rd;

disp(['Rd=' num2str(round(Rd,1)) ' ohm']);
disp(['* R1=' num2str(round(R1/1000,1)) ' kOhm';'* R2=' num2str(round(R2/1000,1)) ' kOhm']);
disp(['* R3=' num2str(round(R3,1)) ' Ohm';'* R4=' num2str(round(R4,1)) ' Ohm']);